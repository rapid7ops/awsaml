
#!/bin/bash
osascript ~/Library/awsaml-update.js &
